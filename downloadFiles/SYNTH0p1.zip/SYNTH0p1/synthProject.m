function [estimated, lambda]=synthProject(voices, target)

% SYNTHPROJECT Project from latent points to voices.
%
%	Description:
%
%	SYNTHPROJECT projects from latent positions back to voices.
%	


%	Copyright (c) 2009 Jon Barker
% 	synthProject.m SVN version 498
% 	last update 2009-09-03T06:21:14.000000Z
  
  N=size(voices,1);

  u=voices*voices';

  invu = pdinv(u);


  lambda = invu * voices * target';
  estimated = lambda' * voices;
end
