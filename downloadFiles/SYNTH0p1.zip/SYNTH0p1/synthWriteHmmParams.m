function synthWriteHmmParams(name, params);

% SYNTHWRITEHMMPARAMS Write the HMM parameters to a file.
%
%	Description:
%
%	SYNTHWRITEHMMPARAMS(NAME, PARAMS) writes the HMM parameters to a
%	file for input into HTK by the perl script.
%	 Arguments:
%	  NAME - the file name.
%	  PARAMS - the parameters to write.
%	
%
%	See also
%	SYNTHEIGENVOICESETUP, SYNTHPROJECTIONCALLBACK


%	Copyright (c) 2009 Jon Barker
% 	synthWriteHmmParams.m SVN version 503
% 	last update 2009-09-05T21:36:50.000000Z
  
  fid = fopen(name,'wt');
  fprintf(fid,'%f ',params);
  fprintf(fid,'\n');
  fclose(fid);
end