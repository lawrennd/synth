function [columns, h, spec_im] = synthDisplaySpectrogram(ax, filename, desired_ncolumns)  

% SYNTHDISPLAYSPECTROGRAM Display the synthesized spectrogram.
%
%	Description:
%
%	[COLS, H] = SYNTHDISPLAYSPECTROGRAM(AX, FILENAME, NCOLS) displays
%	the spectrogram of the given file name in the given axis.
%	 Returns:
%	  COLS - the columns size of the spectrogram.
%	  H - handle to the image data from the spectrogram.
%	 Arguments:
%	  AX - the axis to disply on.
%	  FILENAME - the file to display.
%	  NCOLS - the desired number of columns to display.
%	
%	
%
%	See also
%	DEMEIGENVOICELATENT, DEMPROJECTVOICES


%	Copyright (c) 2009 Jon Barker


%	With modifications by Neil D. Lawrence 2009
% 	synthDisplaySpectrogram.m SVN version 503
% 	last update 2009-09-05T18:11:54.000000Z

  if nargout < 3
    axes(ax);
  end
  x = wavread(filename); 
  sp = myspectrogram(x, 2048, 8000); 
  spec_im = flipud(log(abs(sp(1:700,:))));
  ncolumns = size(spec_im, 2);
  if (nargin==3) 
    if (desired_ncolumns<ncolumns)
      % Truncate spectrogram to desired width
      spec_im = spec_im(:, 1:desired_ncolumns);
    elseif (desired_ncolumns>ncolumns)
      % Pad spectrogram to desired width
      pad=zeros(700,desired_ncolumns-ncolumns);
      spec_im = [spec_im pad];
    end
  end
  if nargout < 3
    h = imagesc(spec_im);
    drawnow;
  else
    h = [];
  end
  columns=size(spec_im,2);
end
