#!/usr/bin/perl
# ----------------------------------------------------------------- #
#           The HMM-Based Speech Synthesis System (HTS)             #
#           developed by HTS Working Group                          #
#           http://hts.sp.nitech.ac.jp/                             #
# ----------------------------------------------------------------- #
#                                                                   #
#  Copyright (c) 2001-2008  Nagoya Institute of Technology          #
#                           Department of Computer Science          #
#                                                                   #
#                2001-2008  Tokyo Institute of Technology           #
#                           Interdisciplinary Graduate School of    #
#                           Science and Engineering                 #
#                                                                   #
# All rights reserved.                                              #
#                                                                   #
# Redistribution and use in source and binary forms, with or        #
# without modification, are permitted provided that the following   #
# conditions are met:                                               #
#                                                                   #
# - Redistributions of source code must retain the above copyright  #
#   notice, this list of conditions and the following disclaimer.   #
# - Redistributions in binary form must reproduce the above         #
#   copyright notice, this list of conditions and the following     #
#   disclaimer in the documentation and/or other materials provided #
#   with the distribution.                                          #
# - Neither the name of the HTS working group nor the names of its  #
#   contributors may be used to endorse or promote products derived #
#   from this software without specific prior written permission.   #
#                                                                   #
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND            #
# CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,       #
# INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF          #
# MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE          #
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS #
# BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,          #
# EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED   #
# TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     #
# DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON #
# ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,   #
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY    #
# OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE           #
# POSSIBILITY OF SUCH DAMAGE.                                       #
# ----------------------------------------------------------------- #


# Settings ==============================
$qnum = '001';
$ver  = '1';

@SET        = ('cmp','dur');
@cmp        = ('mgc','lf0');
@dur        = ('dur');
$ref{'cmp'} = \@cmp;
$ref{'dur'} = \@dur;

%vflr = ('mgc' => '0.01', # variance floors
         'lf0' => '0.01',
         'dur' => '0.01');

%thr  = ('mgc' => '000',  # minimum state occupancy 
         'lf0' => '000',
         'dur' => '000');

%mdlf = ('mgc' => '1.0',  # tree size control param. for MDL
         'lf0' => '1.0',
         'dur' => '1.0');

%mocc = ('mgc' => '10.0',  # minimum occupancy counts
         'lf0' => '10.0',
         'dur' => ' 5.0');

%gam  = ('mgc' => '000',  # stats load threshold
         'lf0' => '000',
         'dur' => '000');

%t2s  = ('mgc' => 'cmp',  # feature type to mmf conversion
         'lf0' => 'cmp',
         'dur' => 'dur');

%strb = ('mgc' => '1',  # stream start
         'lf0' => '2',
         'dur' => '1');

%stre = ('mgc' => '1',  # stream end
         'lf0' => '4',
         'dur' => '5');

%msdi = ('mgc' => '0',  # msd information
         'lf0' => '1',
         'dur' => '0');

%strw = ('mgc' => '1.0',  # stream weights
         'lf0' => '1.0',
         'dur' => '1.0');

%ordr = ('mgc' => '25',  # feature order  
         'lf0' => '1',
         'dur' => '5');

%nwin = ('mgc' => '3',  # number of windows
         'lf0' => '3',
         'dur' => '0');

%nblk = ('mgc' => '3',   # number of blocks for transforms
         'lf0' => '1',
         'dur' => '1');

%band = ('mgc' => '24',   # band width for transforms
         'lf0' => '0',
         'dur' => '0');

#%mdcp = ('dy' => 'd',   # model copy
#         'A'  => 'a',
#         'I'  => 'i',
#         'U'  => 'u',
#         'E'  => 'e',
#         'O'  => 'o');


# Speech Analysis/Synthesis Setting ==============
# speech analysis
$sr = 16000;   # sampling rate (Hz)
$fs = 80;      # frame period (point) 
$fw = 0.42;    # frequency warping
$gm = 0;   # pole/zero representation weight
$ul = 0;   # use MGC-LSPs instead of MGC coefficients
$lg = 1;   # use log gain instead of linear gain
$fr = $fs/$sr; # frame period (sec)

# speech synthesis
$pf = 1.4;     # postfiltering factor
$fl = 4096;    # length of impulse response
$co = 2047;    # order of cepstrum to approximate mel-generalized cepstrum


# Modeling/Generation Setting ==============
# modeling
$nState = 5;                # number of states
$nIte   = 5;                # number of iterations for embedded training 
$beam   = '1500 100 5000';  # initial, inc, and upper limit of beam width
$maxdev = 10;                # max standard dev coef to control HSMM maximum duration
$mindur = 5;                # min state duration to be evaluated  
$wf     = 3;                # mixture weight flooring

# generation
$maxEMiter  = 20;      # max EM iteration
$EMepsilon  = 0.0001;  # convergence factor for EM iteration
$useGV      = 1;       # turn on GV
$maxGViter  = 50;      # max GV iteration
$GVepsilon  = 0.0001;  # convergence factor for GV iteration
$minEucNorm = 0.01;    # minimum Euclid norm for GV iteration 
$stepInit   = 1.0;     # initial step size
$stepInc    = 1.2;     # step size acceleration factor
$stepDec    = 0.5;     # step size deceleration factor
$hmmWeight  = 1.0;     # weight for HMM output prob.
$gvWeight   = 1.0;     # weight for GV output prob.
$optKind    = 'NEWTON'; # optimization method (STEEPEST, NEWTON, or LBFGS)


# Directories & Commands ===============
# project directories
#$prjdir = '..';

# HTS commands
$HMGENS = "$prjdir/bin/HMGenS";

# SPTK commands
# $X2X      = "$prjdir/bin/x2x";
#$F2S = "f2s";
$EXCITE = "excite";
$MGLSADF = "mglsadf";
#$SOX = "sox";
# $FREQT    = "$prjdir/bin/freqt";
# $C2ACR    = "$prjdir/bin/c2acr";
# $VOPR     = "$prjdir/bin/vopr";
# $MC2B     = "$prjdir/bin/mc2b";
# $SOPR     = "$prjdir/bin/sopr";
# $B2MC     = "$prjdir/bin/b2mc";
# $EXCITE   = "$prjdir/bin/excite";
# $LSP2LPC  = "$prjdir/bin/lsp2lpc";
# $MGC2MGC  = "$prjdir/bin/mgc2mgc";
# $MGLSADF  = "$prjdir/bin/mglsadf";
# $MERGE    = "$prjdir/bin/merge";
# $BCP      = "$prjdir/bin/bcp";
# $LSPCHECK = "$prjdir/bin/lspcheck";

# SoX (to add RIFF header)

# This should point to local builds.
$SOX = "$prjdir/bin/sox";
$F2S = "$prjdir/bin/f2s";


