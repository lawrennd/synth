function dir = synthDirectory

% SYNTHDIRECTORY Returns directory where data is stored.
%
%	Description:
%
%	DIR = SYNTHDIRECTORY returns the directory where this file is
%	located, it is assumed that any data sets downloaded have this
%	directory as their base directory.
%	 Returns:
%	  DIR - the directory where this m-file is stored.
%	
%
%	See also
%	LVMLOADDATA, MAPLOADDATA, DATASETSDIRECTORY


%	Copyright (c) 2005, 2006, 2009 Neil D. Lawrence
% 	synthDirectory.m SVN version 498
% 	last update 2009-09-03T07:58:01.000000Z


% by default return the directory where this file is.
fullSpec = which('synthDirectory');
ind = max(find(fullSpec == filesep));
dir = fullSpec(1:ind);
