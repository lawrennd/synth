function evectors = synthPca(data)

% SYNTHPCA Principal components in the dual space
%
%	Description:
%
%	RETURN = SYNTHPCA(Y) computes the principal components in the dual
%	space.
%	 Returns:
%	  RETURN - W the principal compoents.
%	 Arguments:
%	  Y - the data for the computation.
%	
%
%	See also
%	% SEEALSO


%	Copyright (c) 2009 Jon Barker
% 	synthPca.m SVN version 498
% 	last update 2009-09-03T06:26:03.000000Z
  
  u=data*data';
  
  [pc, d]=eig(u);
  pc=fliplr(pc);

  evectors = pc' * data;
end