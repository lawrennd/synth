
% DEMEIGENVOICELATENT Show latent space of eigenvoices.
%
%	Description:
%	
%	


%	Copyright (c) 2009 Jon Barker


%	With modifications by Neil D. Lawrence 2009
% 	demEigenvoiceLatent.m SVN version 503
% 	last update 2009-09-05T20:35:39.000000Z

global visualiseInfo

[durm, durv] = synthLoadData('dur');
[cmpm, cmpv] = synthLoadData('cmp');
fhandle = figure;

a = ver('matlab');
if strcmp(a.Version, '7.0.1')
  menu = 'listbox';
else
  menu = 'popupmenu';
end

string = {'ay', 'place', 'bbaf3s', 'pbav3s'};
visualiseInfo.utt_popup = uicontrol('Style', menu, ...
                                    'Parent',fhandle, ...
                                    'Units', 'normalized', ...
                                    'Position',[0.02 0.02 0.2 0.05], ...  
                                    'String', string, ...
                                    'Min', 1, 'Max', ...
                                    length(string), 'Value', 3);

h = visualiseInfo.utt_popup;
if(strcmp(menu, 'listbox'))
  set(h, 'listboxtop', get(h, 'value'));
end

string = {'Duration', 'Vocal'};
visualiseInfo.datatype_popup = uicontrol('Style', menu, ...
                              'Parent', fhandle, ...
                              'Units','normalized', ...
                              'Position',[0.22 0.02 0.2 0.05], ...
                              'String', string,  ...
                              'Min', 1, ...
                              'Max', length(string), ...
                              'Value', 2);

h = visualiseInfo.datatype_popup;
if(strcmp(menu, 'listbox'))
  set(h, 'listboxtop', get(h, 'value'));
%  set(h, 'callback', 'set(h, ''listboxtop'', get(h, ''value''))');
end

string = {' X: 1 ',' X: 2 ',' X: 3 ',' X: 4 '};
visualiseInfo.d1_popup = uicontrol('Style', menu, ...
                        'Parent', fhandle, ...
                        'Units','normalized', ...
                        'Position',[0.42 0.02 0.2 0.05], ...
                        'String', string, ...
                        'Min', 1, ...
                        'Max', length(string), ...
                        'Value', 1);
h = visualiseInfo.d1_popup;
if(strcmp(menu, 'listbox'))
  set(h, 'listboxtop', get(h, 'value'));
end

string = {' Y: 1 ',' Y: 2 ',' Y: 3 ',' Y: 4 '};
visualiseInfo.d2_popup = uicontrol('Style', menu, ...
                        'Parent', fhandle, ...
                        'Units', 'normalized', ...
                        'Position', [0.62 0.02 0.2 0.05], ...
                        'String', string, ...
                        'Min', 1, ...
                        'Max', length(string), ...
                        'Value', 2);
h = visualiseInfo.d2_popup;
if(strcmp(menu, 'listbox'))
  set(h, 'listboxtop', get(h, 'value'));
end
  

uicontrol('Parent', fhandle, ...
          'Units','normalized', ...
          'Callback','synthEigenvoiceCallback', ...
          'Position',[0.82 0.02 0.15 0.05], ...
          'String','Run');


visualiseInfo.spec1plot = subplot('Position',[0.01, 0.8, 0.98, 0.2]);
set(visualiseInfo.spec1plot, 'Visible','off');
visualiseInfo.spec2plot = subplot('Position',[0.01, 0.6, 0.98, 0.2]);
set(visualiseInfo.spec2plot, 'Visible','off');


visualiseInfo.plotAxes = subplot('Position',[0.01, 0.15, 0.98, 0.45]);
set(visualiseInfo.plotAxes, 'Visible','off');
visualiseInfo.durm=durm;
visualiseInfo.durv=durv;
visualiseInfo.cmpm=cmpm;
visualiseInfo.cmpv=cmpv;

set(gcf,'UserData', visualiseInfo)


