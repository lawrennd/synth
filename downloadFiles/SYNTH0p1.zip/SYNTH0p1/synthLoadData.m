function [m, v, lbls] = synthLoadData(dataset, seedVal)

% SYNTHLOADDATA Load a latent variable model dataset.
%
%	Description:
%
%	[M, V, LBLS] = SYNTHLOADDATA(DATASET) loads a data set for a latent
%	variable modelling problem.
%	 Returns:
%	  M - the HMM means.
%	  V - the HMM variances.
%	  LBLS - the labels.
%	 Arguments:
%	  DATASET - the name of the data set to be loaded, either 'cmp' or
%	   'dur'.
%	
%
%	See also
%	MAPLOADDATA, LVMLOADDATA


%	Copyright (c) 2004, 2005, 2006, 2008, 2009 Neil D. Lawrence
% 	synthLoadData.m SVN version 503
% 	last update 2009-09-04T21:58:39.000000Z

  if nargin > 1
    randn('seed', seedVal)
    rand('seed', seedVal)
  end

  lbls = [1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 0, 1, 0, 1, 0, ...
          0, 0, 0, 0, 0, 1, 1, 1, 0, 1, 0, 1, 0, 0]';
  lbls = [lbls ~lbls];

  
  % get directory
  baseDir = synthDirectory;
  dirSep = filesep;
  switch dataset
   case 'cmp'
    try 
      load([baseDir 'data' filesep dataset '.mat']);
    catch
      [void, errid] = lasterr;
      if strcmp(errid, 'MATLAB:load:couldNotReadFile');
        disp('Loading mfcc means...');
        m=load([synthDirectory 'data/cmp.mean']);
        disp('Loading mfcc variances...');
        v=load([synthDirectory 'data/cmp.var']);        
        
        save([baseDir 'data' filesep dataset '.mat'], 'm', 'v', 'lbls');
      else
        error(lasterr);
      end
    end
      
   case 'dur'
    try 
      load([baseDir 'data' filesep dataset '.mat']);
    catch
      [void, errid] = lasterr;
      if strcmp(errid, 'MATLAB:load:couldNotReadFile');
        disp('Loading duration means...');
        m = load([synthDirectory 'data/dur.mean']);
        disp('Loading duration variances...');
        v = load([synthDirectory 'data/dur.var']);
        save([baseDir 'data' filesep dataset '.mat'], 'm', 'v', 'lbls');
      else
        error(lasterr);
      end
    end
    
   otherwise
    error('Unknown data set requested.')
    
  end

  retLbls = cell(2, 1);
  retLbls{1} = lbls;
  retLbls{2} = {'JB', 'Martin Cooke', 'Stuart Cunningham', 'Sue Harding', ...
                'Jonny Laidler', 'Stuart Wriggley', 'Gillian', 'Mike Stannett', ...
                'John Karn', 'UG', 'Anna', 'UG', ...
                'UG', 'UG', 'Female', 'UG', ...
                'UG', 'UG',  'UG', 'UG', ...
                'UG', 'UG', 'UG', 'UG', ...
                'UG', 'James Carmichael', 'Rob Mill', 'Matt Gibson', ...
                'Sarah Simpson', 'Vinny Wan', 'Lucy', 'NDL', ...
                'UG', 'UG'};
  lbls = retLbls;
  
end
