
% SYNTHTOOLBOXES Toolboxes required for Synth demos.
%
%	Description:
%	% 	synthToolboxes.m SVN version 498
% 	last update 2009-09-03T07:35:45.000000Z
importLatest('voicebox');
importTool('mltools');
importLatest('ndlutil');
