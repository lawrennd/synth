function [normalised, meandata] = synthNormaliseData(data)

% SYNTHNORMALISEDATA Subtract the mean from the data.
%
%	Description:
%
%	Y = SYNTHNORMALISEDATA(Y) subtracts the mean from the data and
%	performs any other normalization.
%	 Returns:
%	  Y - the normalized data. REUTRN mu : the mean.
%	 Arguments:
%	  Y - the data.


%	Copyright (c) 2009 Jon Barker
% 	synthNormaliseData.m SVN version 503
% 	last update 2009-09-05T21:34:14.000000Z
  
  meandata = mean(data);
  normalised = data - repmat(meandata, size(data,1), 1);
end