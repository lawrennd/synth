#include <stdlib.h>
#include <stdio.h>
#include <math.h>

int main(int argc, char *argv[]) {

  FILE *infile;

  FILE *outfile;

  float *buffer;
  float f;
  int nfloats=0;
  int i=0;
  short int  ss;
  float maxx;
  
  infile=fopen(argv[1],"r");

  if (infile==NULL) {
    fprintf(stderr,"Cannot open file: %s\n",argv[1]);
    exit(-1);
  }
  
  while (fread(&f,4,1,infile))
    nfloats++;
  fclose(infile);
  
  buffer = (float*)malloc(sizeof(float)*nfloats);

  if (buffer==NULL) {
    fprintf(stderr,"Memory allocation failure\n");
    exit(-1);
  }

  infile=fopen(argv[1],"r");

  if (infile==NULL) {
    fprintf(stderr,"Cannot open file: %s\n",argv[1]);
    exit(-1);
  }

  fread(buffer,4,nfloats,infile);
  
  fclose(infile);

  maxx=buffer[0];
  for (i=1; i<nfloats;i++) {
    if (fabs(buffer[i])>maxx) maxx=fabs(buffer[i]);
  }

  for (i=0; i<nfloats;i++) {
    buffer[i]=buffer[i]/maxx*256.0*128.0 * 0.9;
  }

  outfile=fopen(argv[2],"wb");
 
  for (i=0; i<nfloats;i++) {
    ss=(short)(buffer[i]);
    //    fprintf(stderr,"%d\n", nfloats);
    fwrite(&ss,sizeof(short),1,outfile);
  }

  fclose(outfile);

  return 0;
}
