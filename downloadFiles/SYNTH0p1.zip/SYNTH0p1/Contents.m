% SYNTH toolbox
% Version 0.1		06-Sep-2009
% Copyright (c) 2009, Neil D. Lawrence
% 
, Neil D. Lawrence
% SYNTHEIGENVOICESETUP Sets up the demo or the eigenvoices.
% SYNTHSCATTERSPEAKERS Do PCA and scatter plot the speakers.
% SYNTHDISPLAYSPECTROGRAM Display the synthesized spectrogram.
% SYNTHVISUALISE For synthesizing a voice.
% SYNTHNORMALISEDATA Subtract the mean from the data.
% DEMEIGENVOICELATENT Show latent space of eigenvoices.
% SYNTHPROJECTIONCALLBACK Callback function for the projection interface.
%MYSPECTROGRAM Calculate spectrogram from signal.
% SYNTHMODIFY Helper code for synthesis of voices.
% SYNTHPCA Principal components in the dual space
% SYNTHWRITEHMMPARAMS Write the HMM parameters to a file.
% SYNTHEIGENVOICECALLBACK Callback function for the eigenvoice demo.
% SYNTHTOOLBOXES Toolboxes required for Synth demos.
% DEMPROJECTVOICES Demonstrate projection of voices onto reduced dimension.
% SYNTHPROJECT Project from latent points to voices.
% SYNTHDIRECTORY Returns directory where data is stored.
% SYNTHSPECTROGRAMCALLBACK Callback for plot of spectrogram.
% SYNTHLOADDATA Load a latent variable model dataset.
